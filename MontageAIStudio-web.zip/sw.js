// Service worker minimal : met en cache uniquement l'app shell (HTML/CSS/JS)
// pour permettre l'ouverture de l'app hors ligne. Les traitements vidéo et
// les appels aux API IA nécessitent toujours une connexion internet.

const CACHE_NAME = "montage-ai-shell-v1";
const SHELL_FILES = [
  "./",
  "./index.html",
  "./css/style.css",
  "./js/app.js",
  "./js/engine.js",
  "./js/ai-planner.js",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_FILES))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Ne jamais mettre en cache les appels vers des CDN externes (ffmpeg.wasm)
  // ou vers les API IA : on laisse le réseau gérer, avec repli sur le cache
  // seulement pour les fichiers de l'app shell (même origine).
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(event.request).then((cached) => cached || fetch(event.request))
  );
});

// app.js — Orchestrateur principal : relie l'interface aux modules engine.js
// et ai-planner.js, et exécute le pipeline de montage complet.

import * as Engine from "./engine.js";
import { buildEditPlan, transcribeAudio, segmentsToSrt } from "./ai-planner.js";

// ---------------------------------------------------------------- ÉTAT
const state = {
  clips: [],       // File[]
  music: null,     // File | null
};

// ---------------------------------------------------------------- UI HELPERS
const $ = (id) => document.getElementById(id);

function switchTab(tabId) {
  document.querySelectorAll(".tab-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === tabId));
  document.querySelectorAll(".tab-panel").forEach(p => p.classList.toggle("active", p.id === `tab-${tabId}`));
}

document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => switchTab(btn.dataset.tab));
});

function log(message) {
  const box = $("logBox");
  const time = new Date().toLocaleTimeString("fr-FR");
  box.textContent += `[${time}] ${message}\n`;
  box.scrollTop = box.scrollHeight;
}

function setProgress(fraction, status) {
  $("progressBar").style.width = `${Math.round(Math.max(0, Math.min(1, fraction)) * 100)}%`;
  if (status) $("statusLabel").textContent = status;
}

Engine.setLogHandler((msg) => {
  // Les logs bruts ffmpeg sont verbeux : on les garde discrets dans la console,
  // et on pousse nos propres messages d'étape via log() ailleurs.
  console.debug("[ffmpeg]", msg);
});

// ---------------------------------------------------------------- COMPAT CHECK
if (typeof WebAssembly === "undefined") {
  $("compat-warning").hidden = false;
}

// ---------------------------------------------------------------- INPUTS
$("clipsInput").addEventListener("change", (e) => {
  state.clips = Array.from(e.target.files);
  $("clipsSummary").textContent = state.clips.length
    ? `✓ ${state.clips.length} clip(s) sélectionné(s) : ${state.clips.map(f => f.name).join(", ")}`
    : "Aucun clip sélectionné.";
});

$("musicInput").addEventListener("change", (e) => {
  state.music = e.target.files[0] || null;
  $("musicSummary").textContent = state.music
    ? `✓ ${state.music.name}`
    : "Aucune musique sélectionnée.";
});

$("durationSlider").addEventListener("input", (e) => {
  $("durationValue").textContent = e.target.value;
});
$("volumeSlider").addEventListener("input", (e) => {
  $("volumeValue").textContent = e.target.value;
});

// Persistance légère des clés API en localStorage
$("anthropicKey").value = localStorage.getItem("montage_ai_anthropic_key") || "";
$("openaiKey").value = localStorage.getItem("montage_ai_openai_key") || "";
$("anthropicKey").addEventListener("change", (e) => {
  localStorage.setItem("montage_ai_anthropic_key", e.target.value);
});
$("openaiKey").addEventListener("change", (e) => {
  localStorage.setItem("montage_ai_openai_key", e.target.value);
});

// ---------------------------------------------------------------- PIPELINE
$("generateBtn").addEventListener("click", runPipeline);

async function runPipeline() {
  const btn = $("generateBtn");
  btn.disabled = true;
  btn.textContent = "Génération en cours...";
  $("logBox").textContent = "";
  $("resultCard").hidden = true;
  switchTab("generate");

  try {
    await runPipelineInner();
  } catch (err) {
    console.error(err);
    log(`❌ ERREUR : ${err.message}`);
    setProgress(0, "Échec — voir le journal ci-dessus.");
    alert(`Erreur : ${err.message}`);
  } finally {
    btn.disabled = false;
    btn.textContent = "▶ Générer le montage";
  }
}

async function runPipelineInner() {
  if (!state.clips.length) throw new Error("Sélectionne au moins un clip vidéo.");

  const targetSeconds = parseInt($("durationSlider").value, 10) * 60;
  const musicVolume = parseInt($("volumeSlider").value, 10) / 100;
  const doSilences = $("optSilences").checked;
  const doTransitions = $("optTransitions").checked;
  const doSubtitles = $("optSubtitles").checked;
  const doBurnSubs = $("optBurnSubs").checked;
  const doAi = $("optAiMode").checked;

  log("Chargement du moteur vidéo (ffmpeg.wasm)... premier lancement plus long.");
  setProgress(0.03, "Chargement du moteur vidéo...");
  await Engine.loadEngine((p) => {
    // progress events pendant exec ffmpeg ; on les laisse discrets ici
  });

  // --- Étape 0 : écrire les fichiers dans le FS virtuel ---
  log(`${state.clips.length} clip(s) à traiter.`);
  const clipEntries = [];
  for (let i = 0; i < state.clips.length; i++) {
    const file = state.clips[i];
    const name = `input_${i}${extOf(file.name)}`;
    await Engine.writeInputFile(file, name);
    const duration = await Engine.probeDuration(name);
    clipEntries.push({ name, duration, originalName: file.name });
    log(`  Chargé : ${file.name} (${duration.toFixed(1)}s)`);
    setProgress(0.03 + 0.12 * (i + 1) / state.clips.length);
  }

  let musicName = null;
  if (state.music) {
    musicName = `music${extOf(state.music.name)}`;
    await Engine.writeInputFile(state.music, musicName);
    log(`Musique chargée : ${state.music.name}`);
  }

  // --- Étape 1 : suppression des silences ---
  let workingClips = clipEntries;
  if (doSilences) {
    log("Étape 1/4 — Suppression automatique des silences...");
    const cleaned = [];
    for (let i = 0; i < clipEntries.length; i++) {
      const c = clipEntries[i];
      const outName = `clean_${i}.mp4`;
      const result = await Engine.cutSilences(c.name, outName, c.duration);
      const newDuration = result === c.name ? c.duration : await Engine.probeDuration(result);
      cleaned.push({ name: result, duration: newDuration, originalName: c.originalName });
      log(`  ✓ ${c.originalName} traité`);
      setProgress(0.15 + 0.25 * (i + 1) / clipEntries.length);
    }
    workingClips = cleaned;
  } else {
    log("Étape 1/4 — Suppression des silences désactivée.");
    setProgress(0.40);
  }

  // --- Étape 2 : plan de montage ---
  log("Étape 2/4 — Construction du plan de montage...");
  let plan;
  if (doAi) {
    const apiKey = $("anthropicKey").value.trim();
    const scriptText = $("scriptBox").value.trim();
    const clipsInfo = workingClips.map(c => ({
      file: c.name, duration: Math.round(c.duration * 10) / 10
    }));
    log("  Appel à l'API Claude pour générer le plan...");
    const aiResult = await buildEditPlan(apiKey, clipsInfo, scriptText, targetSeconds);
    plan = aiResult.plan;
    if (aiResult.notes) log(`  Note de l'IA : ${aiResult.notes}`);
  } else {
    plan = Engine.buildSimplePlan(
      workingClips.map(c => ({ name: c.name, duration: c.duration })),
      targetSeconds
    );
  }
  setProgress(0.55, "Plan de montage prêt.");

  // --- Étape 3 : assemblage + musique ---
  log("Étape 3/4 — Assemblage vidéo et transitions...");
  let assembled = await Engine.assembleVideo(plan, { transitions: doTransitions, height: 720 });
  setProgress(0.75, "Vidéo assemblée.");

  if (musicName) {
    log("  Mixage de la musique de fond...");
    assembled = await Engine.mixMusic(assembled, musicName, musicVolume);
  }
  setProgress(0.85, "Assemblage terminé.");

  // --- Étape 4 : sous-titres (optionnel) ---
  let srtContent = null;
  if (doSubtitles) {
    log("Étape 4/4 — Transcription pour les sous-titres...");
    const openaiKey = $("openaiKey").value.trim();
    try {
      // Extrait la piste audio en mp3 (léger) pour l'envoyer à l'API Whisper
      await Engine.getFFmpeg().exec(["-i", assembled, "-vn", "-acodec", "libmp3lame", "-b:a", "96k", "audio_track.mp3"]);
      const audioData = await Engine.readOutputFile("audio_track.mp3");
      const audioBlob = new Blob([audioData.buffer], { type: "audio/mp3" });
      const segments = await transcribeAudio(openaiKey, audioBlob, "audio.mp3");
      srtContent = segmentsToSrt(segments);
      log(`  ✓ ${segments.length} segments de sous-titres générés.`);

      if (doBurnSubs) {
        try {
          await Engine.getFFmpeg().writeFile("subs.srt", srtContent);
          const burnedName = "burned.mp4";
          await Engine.getFFmpeg().exec([
            "-i", assembled, "-vf", "subtitles=subs.srt",
            "-c:a", "copy", burnedName
          ]);
          assembled = burnedName;
          log("  ✓ Sous-titres incrustés dans la vidéo.");
        } catch (e) {
          log("  ⚠ Incrustation des sous-titres impossible sur ce build ffmpeg.wasm — "
            + "le fichier .srt reste téléchargeable séparément.");
        }
      }
    } catch (e) {
      log(`  ⚠ Sous-titres impossibles : ${e.message}`);
    }
  } else {
    log("Étape 4/4 — Sous-titres désactivés.");
  }

  // --- Résultat final ---
  const outputData = await Engine.readOutputFile(assembled);
  const blob = new Blob([outputData.buffer], { type: "video/mp4" });
  const url = URL.createObjectURL(blob);

  $("resultVideo").src = url;
  $("downloadLink").href = url;
  $("downloadLink").download = `montage_${Date.now()}.mp4`;

  if (srtContent) {
    const srtBlob = new Blob([srtContent], { type: "text/plain" });
    $("downloadSrt").href = URL.createObjectURL(srtBlob);
    $("downloadSrt").hidden = false;
  } else {
    $("downloadSrt").hidden = true;
  }

  $("resultCard").hidden = false;
  setProgress(1, "Terminé ✓");
  log("✅ Montage terminé.");
}

function extOf(filename) {
  const idx = filename.lastIndexOf(".");
  return idx >= 0 ? filename.slice(idx) : ".mp4";
}

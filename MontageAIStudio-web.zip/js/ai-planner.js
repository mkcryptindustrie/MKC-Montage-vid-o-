// ai-planner.js — Appelle directement l'API Anthropic depuis le navigateur
// pour obtenir un plan de montage à partir d'un script utilisateur.
// La clé API n'est utilisée que pour cet appel, jamais transmise ailleurs.

const SYSTEM_PROMPT = `Tu es un monteur vidéo professionnel spécialisé dans le montage \
automatique. On te donne une liste de clips disponibles (nom de fichier et durée \
en secondes), un script ou plan narratif fourni par l'utilisateur, et une durée \
cible pour la vidéo finale. Tu dois répondre UNIQUEMENT avec un objet JSON valide, \
sans texte autour, ni balises markdown, au format suivant :

{
  "plan": [
    {"file": "nom_du_clip.mp4", "start": 0, "end": 12.5, "reason": "courte explication"}
  ],
  "notes": "remarques générales sur le montage proposé"
}

Règles :
- N'utilise que des fichiers présents dans la liste fournie.
- "start" et "end" doivent rester dans la durée réelle du clip fourni.
- La somme des durées (end - start) du plan doit s'approcher le plus possible \
de la durée cible, à +/- 5% près.
- Respecte l'ordre logique du script/plan fourni par l'utilisateur.
- Privilégie un rythme dynamique : évite les segments de plus de 45 secondes \
sauf si le script l'exige explicitement.`;

export async function buildEditPlan(apiKey, clipsInfo, scriptText, targetSeconds) {
  if (!apiKey) throw new Error("Aucune clé API Anthropic renseignée.");

  const userMessage = JSON.stringify({
    clips_disponibles: clipsInfo,
    duree_cible_secondes: targetSeconds,
    script_utilisateur: scriptText,
  }, null, 2);

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model: "claude-sonnet-4-6",
      max_tokens: 4000,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }],
    }),
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erreur API Anthropic (${response.status}) : ${errText}`);
  }

  const data = await response.json();
  let rawText = data.content
    .filter(b => b.type === "text")
    .map(b => b.text)
    .join("")
    .trim();

  if (rawText.startsWith("```")) {
    rawText = rawText.replace(/^```(json)?/i, "").replace(/```$/, "").trim();
  }

  let plan;
  try {
    plan = JSON.parse(rawText);
  } catch (e) {
    throw new Error(`Réponse IA non exploitable (JSON invalide) : ${e.message}`);
  }

  if (!plan.plan || !Array.isArray(plan.plan) || plan.plan.length === 0) {
    throw new Error("Le plan renvoyé par l'IA est vide ou mal formé.");
  }

  return plan;
}

// ------------------------------------------------------------------
// Sous-titres automatiques via l'API Whisper d'OpenAI (optionnel)
// ------------------------------------------------------------------
export async function transcribeAudio(apiKey, audioBlob, filename = "audio.mp3") {
  if (!apiKey) throw new Error("Aucune clé API OpenAI renseignée pour les sous-titres.");

  const formData = new FormData();
  formData.append("file", audioBlob, filename);
  formData.append("model", "whisper-1");
  formData.append("response_format", "verbose_json");

  const response = await fetch("https://api.openai.com/v1/audio/transcriptions", {
    method: "POST",
    headers: { "Authorization": `Bearer ${apiKey}` },
    body: formData,
  });

  if (!response.ok) {
    const errText = await response.text();
    throw new Error(`Erreur API Whisper (${response.status}) : ${errText}`);
  }

  const data = await response.json();
  return data.segments || [];
}

function formatSrtTimestamp(seconds) {
  const ms = Math.round(seconds * 1000);
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const msRem = ms % 1000;
  const pad = (n, len = 2) => String(n).padStart(len, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(msRem, 3)}`;
}

export function segmentsToSrt(segments) {
  return segments.map((seg, i) => {
    return `${i + 1}\n${formatSrtTimestamp(seg.start)} --> ${formatSrtTimestamp(seg.end)}\n${seg.text.trim()}\n`;
  }).join("\n");
}

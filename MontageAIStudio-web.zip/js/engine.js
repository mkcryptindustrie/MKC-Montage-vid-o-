// engine.js — Moteur de montage vidéo exécuté entièrement dans le navigateur
// via ffmpeg.wasm (build single-thread, compatible GitHub Pages sans headers
// COOP/COEP particuliers).

import { FFmpeg } from "https://cdn.jsdelivr.net/npm/@ffmpeg/ffmpeg@0.12.10/dist/esm/index.js";
import { fetchFile, toBlobURL } from "https://cdn.jsdelivr.net/npm/@ffmpeg/util@0.12.1/dist/esm/index.js";

const CORE_BASE = "https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/dist/esm";

let ffmpeg = null;
let logHandler = () => {};

export function setLogHandler(fn) {
  logHandler = fn;
}

/** Charge ffmpeg.wasm (une seule fois, réutilisé ensuite). */
export async function loadEngine(onProgress) {
  if (ffmpeg) return ffmpeg;

  ffmpeg = new FFmpeg();
  ffmpeg.on("log", ({ message }) => {
    logHandler(message);
    _captureSilenceLog(message);
  });
  if (onProgress) {
    ffmpeg.on("progress", ({ progress }) => onProgress(progress));
  }

  await ffmpeg.load({
    coreURL: await toBlobURL(`${CORE_BASE}/ffmpeg-core.js`, "text/javascript"),
    wasmURL: await toBlobURL(`${CORE_BASE}/ffmpeg-core.wasm`, "application/wasm"),
  });

  return ffmpeg;
}

// ------------------------------------------------------------------
// Détection des silences (parsing des logs ffmpeg silencedetect)
// ------------------------------------------------------------------
let _silenceBuffer = [];
function _captureSilenceLog(message) {
  const startMatch = message.match(/silence_start:\s*([0-9.]+)/);
  const endMatch = message.match(/silence_end:\s*([0-9.]+)/);
  if (startMatch) _silenceBuffer.push({ type: "start", t: parseFloat(startMatch[1]) });
  if (endMatch) _silenceBuffer.push({ type: "end", t: parseFloat(endMatch[1]) });
}

async function detectSilences(inputName, noiseDb = -35, minLen = 0.6) {
  _silenceBuffer = [];
  await ffmpeg.exec([
    "-i", inputName,
    "-af", `silencedetect=noise=${noiseDb}dB:d=${minLen}`,
    "-f", "null", "-"
  ]);
  const starts = _silenceBuffer.filter(e => e.type === "start").map(e => e.t);
  const ends = _silenceBuffer.filter(e => e.type === "end").map(e => e.t);
  const n = Math.min(starts.length, ends.length);
  const silences = [];
  for (let i = 0; i < n; i++) silences.push([starts[i], ends[i]]);
  return silences;
}

function computeKeepSegments(duration, silences, padding = 0.15, minGap = 0.4) {
  if (!silences.length) return [[0, duration]];
  const keep = [];
  let cursor = 0;
  for (const [sStart, sEnd] of silences) {
    const segStart = cursor;
    const segEnd = Math.max(cursor, sStart + padding);
    if (segEnd - segStart > minGap) keep.push([segStart, segEnd]);
    cursor = Math.max(cursor, sEnd - padding);
  }
  if (duration - cursor > minGap) keep.push([cursor, duration]);
  return keep.length ? keep : [[0, duration]];
}

/**
 * Supprime les silences d'un clip. Écrit le résultat sous outputName dans le FS
 * virtuel de ffmpeg. Renvoie le nom du fichier utile en sortie (peut être
 * inputName inchangé si aucun silence significatif n'est trouvé).
 */
export async function cutSilences(inputName, outputName, duration) {
  const silences = await detectSilences(inputName);
  const segments = computeKeepSegments(duration, silences);

  if (segments.length <= 1 && segments[0][0] === 0 && segments[0][1] === duration) {
    return inputName; // rien à couper
  }

  // Construit un filter_complex trim+concat pour ne garder que les segments utiles
  let filterParts = [];
  let concatInputs = "";
  segments.forEach(([s, e], i) => {
    filterParts.push(`[0:v]trim=start=${s}:end=${e},setpts=PTS-STARTPTS[v${i}]`);
    filterParts.push(`[0:a]atrim=start=${s}:end=${e},asetpts=PTS-STARTPTS[a${i}]`);
    concatInputs += `[v${i}][a${i}]`;
  });
  const filterComplex = filterParts.join(";") +
    `;${concatInputs}concat=n=${segments.length}:v=1:a=1[vout][aout]`;

  await ffmpeg.exec([
    "-i", inputName,
    "-filter_complex", filterComplex,
    "-map", "[vout]", "-map", "[aout]",
    "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
    "-c:a", "aac",
    outputName
  ]);

  return outputName;
}

// ------------------------------------------------------------------
// Assemblage final : normalisation résolution, transitions, concat
// ------------------------------------------------------------------

/** Calcule un plan simple (sans IA) qui ajuste la somme des clips à la durée cible. */
export function buildSimplePlan(clipEntries, targetSeconds) {
  // clipEntries: [{ name, duration }]
  const total = clipEntries.reduce((a, c) => a + c.duration, 0);
  if (total <= targetSeconds || total === 0) {
    return clipEntries.map(c => ({ file: c.name, start: 0, end: c.duration }));
  }
  const ratio = targetSeconds / total;
  return clipEntries.map(c => ({ file: c.name, start: 0, end: c.duration * ratio }));
}

/**
 * Assemble les segments du plan en une vidéo finale, avec transitions en
 * fondu optionnelles et normalisation de résolution (720p, pour rester léger
 * sur mobile).
 */
export async function assembleVideo(plan, { transitions = true, height = 720 } = {}) {
  // Étape 1 : normaliser chaque segment (résolution + trim) en un fichier temporaire
  const normalized = [];
  for (let i = 0; i < plan.length; i++) {
    const seg = plan[i];
    const outName = `seg_${i}.mp4`;
    const fade = transitions ? 0.5 : 0;
    const vf = [
      `scale=-2:${height}`,
    ];
    let filterChain = vf.join(",");
    if (transitions) {
      const fadeInAt = 0;
      filterChain += `,fade=t=in:st=${fadeInAt}:d=${fade}`;
      const dur = seg.end - seg.start;
      filterChain += `,fade=t=out:st=${Math.max(0, dur - fade)}:d=${fade}`;
    }
    await ffmpeg.exec([
      "-i", seg.file,
      "-ss", String(seg.start), "-to", String(seg.end),
      "-vf", filterChain,
      "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
      "-c:a", "aac", "-ar", "44100",
      outName
    ]);
    normalized.push(outName);
  }

  // Étape 2 : concaténation via le concat demuxer (rapide, pas de ré-encodage supplémentaire)
  const listContent = normalized.map(n => `file '${n}'`).join("\n");
  await ffmpeg.writeFile("concat_list.txt", listContent);

  const assembledName = "assembled.mp4";
  await ffmpeg.exec([
    "-f", "concat", "-safe", "0", "-i", "concat_list.txt",
    "-c", "copy", assembledName
  ]);

  return assembledName;
}

/** Mixe une musique de fond sous la piste audio existante (boucle si besoin). */
export async function mixMusic(videoName, musicName, volume = 0.18) {
  const outName = "with_music.mp4";
  await ffmpeg.exec([
    "-i", videoName,
    "-stream_loop", "-1", "-i", musicName,
    "-filter_complex",
    `[1:a]volume=${volume}[music];[0:a][music]amix=inputs=2:duration=first:dropout_transition=2[aout]`,
    "-map", "0:v", "-map", "[aout]",
    "-c:v", "copy", "-shortest",
    outName
  ]);
  return outName;
}

// ------------------------------------------------------------------
// Fichiers : écriture / lecture dans le FS virtuel ffmpeg
// ------------------------------------------------------------------
export async function writeInputFile(file, name) {
  await ffmpeg.writeFile(name, await fetchFile(file));
}

export async function readOutputFile(name) {
  return ffmpeg.readFile(name);
}

export async function probeDuration(name) {
  // ffmpeg.wasm n'expose pas ffprobe : on lit la durée depuis les logs de -i
  let duration = 0;
  const previousHandler = logHandler;
  const handler = (msg) => {
    const m = msg.match(/Duration:\s*(\d+):(\d+):(\d+\.\d+)/);
    if (m) duration = (+m[1]) * 3600 + (+m[2]) * 60 + parseFloat(m[3]);
    previousHandler(msg); // conserve aussi le log dans l'UI
  };
  logHandler = handler;
  try {
    await ffmpeg.exec(["-i", name]);
  } catch (e) {
    // ffmpeg retourne un code d'erreur pour un -i seul sans sortie : normal, on ignore.
  } finally {
    logHandler = previousHandler;
  }
  return duration;
}

export function getFFmpeg() {
  return ffmpeg;
}

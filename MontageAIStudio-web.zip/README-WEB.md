# Montage AI Studio — Version Web (PWA)

Version mobile/web de l'application, installable sur l'écran d'accueil
(Android et iPhone) et hébergeable gratuitement sur GitHub Pages. Tout le
traitement vidéo se fait **dans le navigateur** (via ffmpeg.wasm) — aucun
fichier vidéo n'est envoyé à un serveur.

## ⚠️ Limites à connaître avant de déployer

GitHub Pages n'héberge que du contenu statique (pas de serveur), donc :

- **Pas de traitement de très longues vidéos.** Un téléphone a peu de mémoire
  disponible pour un navigateur : au-delà de quelques clips / ~15 minutes de
  rendu, le navigateur peut ralentir fortement ou planter. Pour du 30 min–2h,
  utilise l'application de bureau (dossier parent de ce projet).
- **Sous-titres automatiques = clé API OpenAI Whisper requise.** Faire tourner
  un modèle de transcription directement sur un téléphone est trop lourd ;
  l'app envoie donc uniquement la piste audio extraite à l'API Whisper si tu
  fournis une clé.
- **Mode IA = clé API Anthropic requise**, appelée directement depuis le
  navigateur (aucun serveur intermédiaire).
- **Incrustation des sous-titres dans la vidéo** est marquée "expérimentale" :
  selon le navigateur, le filtre `subtitles` peut ne pas être disponible dans
  le build ffmpeg.wasm utilisé. Le fichier `.srt` reste toujours téléchargeable
  séparément en secours.

## 1. Déployer sur GitHub Pages

1. Crée un nouveau dépôt GitHub (ex : `montage-ai-studio`).
2. Copie **le contenu du dossier `web/`** (pas le dossier lui-même) à la
   racine du dépôt — ou dans un sous-dossier `/docs` si tu préfères.
3. Pousse le code :
   ```bash
   git init
   git add .
   git commit -m "Montage AI Studio - version web"
   git branch -M main
   git remote add origin https://github.com/<ton-compte>/montage-ai-studio.git
   git push -u origin main
   ```
4. Sur GitHub : **Settings → Pages** → Source : `Deploy from a branch` →
   Branch : `main` / dossier `/ (root)` (ou `/docs` selon ton choix) → Save.
5. Ton app sera disponible après 1-2 minutes à :
   `https://<ton-compte>.github.io/montage-ai-studio/`

## 2. Installer sur le téléphone

**Android (Chrome)** : ouvre l'URL → menu ⋮ → "Ajouter à l'écran d'accueil" /
"Installer l'application".

**iPhone (Safari)** : ouvre l'URL → bouton Partager (carré avec flèche) →
"Sur l'écran d'accueil". *(Safari 16.4+ recommandé pour un bon support
WebAssembly.)*

## 3. Tester en local avant de déployer

GitHub Pages sert en HTTPS, ce qui est nécessaire pour certaines API
navigateur. Pour tester en local avec un serveur simple :

```bash
cd web
python3 -m http.server 8000
```

Puis ouvre `http://localhost:8000` sur ton ordinateur (le mode "ajout à
l'écran d'accueil" ne sera testable qu'une fois déployé en HTTPS, ou via les
outils développeur mobile de Chrome/Safari en USB debugging).

## 4. Structure des fichiers

```
web/
  index.html          → interface (4 onglets : Fichiers, Options, IA, Génération)
  css/style.css        → thème sombre, mobile-first
  js/app.js            → orchestrateur (relie l'UI au moteur)
  js/engine.js          → moteur de montage (ffmpeg.wasm) : silences, assemblage, musique
  js/ai-planner.js       → appels API Anthropic (plan) et OpenAI Whisper (sous-titres)
  manifest.json         → configuration PWA (icône, nom, couleurs)
  sw.js                 → service worker (cache de l'interface pour usage hors-ligne)
  icons/                → icônes de l'app
```

## 5. Pourquoi pas de vraie "installation" comme l'app de bureau ?

Une PWA n'est pas un exécutable : c'est un site web que le téléphone traite
comme une app (icône, plein écran, cache offline pour l'interface). C'est le
seul format qui fonctionne à la fois sur Android et iPhone sans passer par
l'App Store / Play Store, et sans backend à héberger — ce qui correspond à
"hébergeable sur GitHub" que tu as demandé.

## 6. Prochaines améliorations possibles

- Ajouter un mode "basse consommation" (résolution 480p) pour les téléphones
  plus anciens.
- Détection de la mémoire disponible avant de lancer un montage trop ambitieux,
  avec avertissement proactif.
- Support d'une clé API Whisper locale (si un modèle WASM léger devient
  praticable sur mobile).

Dis-moi si tu veux que j'ajuste une de ces briques une fois testée sur ton
téléphone.
